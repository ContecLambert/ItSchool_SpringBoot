package com.naver.dgkim1007.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.naver.dgkim1007.entities.Board;
import com.naver.dgkim1007.entities.BoardPaging;

@Mapper
@Repository
public interface BoardDao {
	public Board selectOne(int b_seq) throws Exception;

	public int insertRow(Board board);

	public int updateRow(Board board);

	public ArrayList<Board> selectAll();

	public int updateAjax(Board board);

	public int deleteAjax(int b_seq);
	
	public ArrayList<Board> selectPageList(BoardPaging boardpaging);
	
	public ArrayList<Board> findListBoard(BoardPaging boardpaging);
	
	public int selectCount();
}