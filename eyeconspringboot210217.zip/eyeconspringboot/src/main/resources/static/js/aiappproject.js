function confirm_email(){
	var yncheck = $('.confirmyn').val();
	if(yncheck=="n"){
		msg = "email 중복 검사를 하세요";
		$('.description').text(msg);
		$('.modal').modal('show');
	}
    
}

$(document).ready(function() {
	$('.confirm').on('click', function() {
      var email = $('#email').val();
      if (email == "") {
         $('.description').text("E-mail을 입력하세요");
         $('.modal').modal('show');
         return;
      } else {
         var email = email;
         $.ajax({
            type : 'POST',
            data : {
               email : email
            },
            datatype : 'json',
            url : 'emailConfirmAjax',
            success : function(data) {
               var msg = "";
               if (data == "y") {
                  msg = "사용중인 email입니다";
                  $('.confirmyn').val('n');
                  $('.description').text(msg);
                  $('.modal').modal('show');
                  $('#email').val('');
                  $('#email').focus();
               } else {
            	   $('.confirmyn').val('y');
                  msg = "사용 가능한 email입니다";
                  $('.description').text(msg);
                  $('.modal').modal('show');
               }
               
            },
            error : function(xhr, status, error) {
               alert('ajax error : ' + xhr.status + error);
            }
         });
      }
   });
   
	$(".attachbtn").on('click', function(){
		$('#b_attachfile').click();
		$('#b_attachfile').change(function() {
			var filename = $('#b_attachfile').val();
			$('.b_attachname').attr('value',filename);
		});
	});
	
/*	$('#b_attachfile').on('change',function(event){
		alert($('#b_attach').val());
//		var attachpath = URL.createObjectURL(event.target.files[0]);		
	})*/
  

	$("#viewphoto").on('click', function(){
	   $('input[type=file]').click();
	   return false;
   	});
   
	$("#imgfile").on('change', function(event){
		var imgpath = URL.createObjectURL(event.target.files[0]);
	 	$('#viewphoto').attr('src',imgpath)
  	});
   
   $('#memberexample').DataTable( {
       deferRender:    true,
       scrollY:        300,
       scrollCollapse: true,
       scroller:       true
   } );
   
   $(document).on('click','#memberexample td #editbtn',function(){
	   var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
	   var td = row.children();
	   var email = td.eq(1).text();
	   var level = td.eq(4).children().val();
	   
	   $.ajax({
		   type : 'POST',
		   data : {email:email,level :level},
		   datatype : 'json',
		   url : 'memberUpdateAjax',
		   success : function(data) {
			   if(data=='y'){
				   $('#resultmessage').text("수정되었습니다.");
			   }else{
				   $('#resultmessage').text("수정되지않았습니다.");
			   }
			   $('#successmsg').css('display',"block")
			   .delay(1200).queue(function(){
				   $('#successmsg').css('display',"none").dequeue();
			   });
		   },
		   error : function(xhr, status, error) {
			   alert('ajax error : ' + xhr.status + error);
		   }
	   });
   });
   
   $(document).on('click','#memberexample td #deletebtn',function(){
	   var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
	   var td = row.children();
	   var email = td.eq(1).text();
	   
	   $('.mini.ui.modal.delete').modal('show');
	   
	   $('#deleteok').on('click',function(){
		   $.ajax({
			   type : 'POST',
			   data : {email:email},
			   datatype : 'json',
			   url : 'memberDeleteAjax',
			   success : function(data) {
				   if(data=='y'){
					   row.remove();
					   $('#resultmessage').text("삭제되었습니다.");
				   }else{
					   $('#resultmessage').text("삭제되지않았습니다.");
				   }
				   $('#successmsg').css('display',"block")
				   .delay(1200).queue(function(){
					   $('#successmsg').css('display',"none").dequeue();
				   });
				   $('.mini.ui.modal.delete').modal('hide');
			   },
			   error : function(xhr, status, error) {
				   alert('ajax error : ' + xhr.status + error);
			   }
		   }); 
	   });
	   
	   $('#cancleok').on('click',function(){
		   $('.mini.ui.modal.delete').modal('hide');
	   });
   });
});