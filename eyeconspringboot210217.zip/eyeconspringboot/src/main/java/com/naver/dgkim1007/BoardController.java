package com.naver.dgkim1007;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.naver.dgkim1007.dao.BoardDao;
import com.naver.dgkim1007.entities.Board;
import com.naver.dgkim1007.entities.Member;

@Controller
public class BoardController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	Member member;
	
    @RequestMapping(value = "/boardWrite", method = RequestMethod.GET)
    public String boardWrite(Locale locale, Model model) {
       return "/board/board_write";
    }
   
    @RequestMapping(value = "/boardSave", method = RequestMethod.POST)
    public String boardSave( Model model,HttpSession session, @ModelAttribute Board board,
    		@RequestParam("b_attachfile") MultipartFile b_attachfile) throws IOException {
    	String filename = b_attachfile.getOriginalFilename();
		String path = "F:/SPRINGBOOTSOURCE/eyeconspringboot/src/main/resources/static/uploadattachs/";     //윈도우즈는 project에서 우클릭 속성
		String realpath = "/uploadattachs/";  //static 아래에 폴더 생성
		String email = (String)session.getAttribute("sessionemail");
		String name = (String)session.getAttribute("sessionname");
		
		board.setB_email(email);
		board.setB_name(name);
		
		if (!filename.equals("")) {
			byte bytes[] = b_attachfile.getBytes();
			try {
				BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(path + filename));
				output.write(bytes);
				output.flush();
				output.close();
				board.setB_attach((realpath + filename));
				} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		BoardDao b_dao = sqlSession.getMapper(BoardDao.class);
		b_dao.insertRow(board);
		
		return "index";
	}
}