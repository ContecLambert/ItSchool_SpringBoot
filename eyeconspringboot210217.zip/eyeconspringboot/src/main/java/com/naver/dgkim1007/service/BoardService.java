package com.naver.dgkim1007.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naver.dgkim1007.dao.BoardDao;
import com.naver.dgkim1007.entities.Board;

@Service
public class BoardService implements BoardDao {
	@Autowired
	BoardDao Boarddao;

	@Override
	public Board selectOne(int b_seq) throws Exception {
		// TODO Auto-generated method stub
		return Boarddao.selectOne(b_seq);
	}

	@Override
	public int insertRow(Board Board) {
		// TODO Auto-generated method stub
		return Boarddao.insertRow(Board);

	}

	@Override
	public int updateRow(Board Board) {
		// TODO Auto-generated method stub
		return Boarddao.updateRow(Board);
	}

	@Override
	public ArrayList<Board> selectAll() {
		// TODO Auto-generated method stub
		return Boarddao.selectAll();
	}

	@Override
	public int updateAjax(Board Board) {
		// TODO Auto-generated method stub
		return Boarddao.updateAjax(Board);
	}

	@Override
	public int deleteAjax(int b_seq) {
		// TODO Auto-generated method stub
		return Boarddao.deleteAjax(b_seq);
	}
}