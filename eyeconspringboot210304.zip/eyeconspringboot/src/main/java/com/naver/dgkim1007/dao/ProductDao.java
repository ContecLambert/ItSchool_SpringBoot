package com.naver.dgkim1007.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.naver.dgkim1007.entities.Product;
import com.naver.dgkim1007.entities.Vender;

@Mapper
@Repository
public interface ProductDao {
	public Product selectOne(String code) throws Exception;
	
	public Vender v_selectOne(String code) throws Exception;
	
	public int insertRow(Product product);
	
	public int v_insertRow(Vender vender);
	
	public int updateRow(Product product);
	
	public int v_updateRow(Vender vender);
	
	public ArrayList<Product> selectAll();
	
	public ArrayList<Vender> v_selectAll();
	
	public int updateAjax(Product product);

	public int deleteAjax(String code);
	
	public int v_deleteAjax(String code);
}