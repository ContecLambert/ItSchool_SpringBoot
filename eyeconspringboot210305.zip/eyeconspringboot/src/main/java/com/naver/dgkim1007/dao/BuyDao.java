package com.naver.dgkim1007.dao;

import java.util.ArrayList;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import com.naver.dgkim1007.entities.Buy;

@Mapper
@Repository
public interface BuyDao {
		
	public Buy selectOne(int seq) throws Exception;

	public int insertRow(Buy buy);
	
	public int updateRow(Map json);

	public int deleteAjax(int seq);
	
	public ArrayList<Buy> selectBuyRollup(Buy buy);
	
	public ArrayList<Buy> selectBuyFindRollup(Model model);
	
	public int getMaxNo(Buy buy);
	
	public int getMaxHang(Buy buy);
	
	public int buyBalanceAdd(Buy buy);
	
}