package com.naver.dgkim1007;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.naver.dgkim1007.dao.ProductDao;
import com.naver.dgkim1007.entities.Balance;
import com.naver.dgkim1007.entities.Product;
import com.naver.dgkim1007.entities.Vender;

@Controller
public class ProductController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	Product product;
	@Autowired
	Vender vender;
	@Autowired
	Balance balance;
	
	@RequestMapping(value = "/productInsert", method = RequestMethod.GET)
	public String productInsert() {
		
		
		return "product/product_insert";
	}
	
	
	@RequestMapping(value = "/codeConfirmAjax", method = RequestMethod.POST)
	@ResponseBody
	public String codeConfirmAjax(@RequestParam String code) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		Product data = dao.selectOne(code);

		String row = "y";
		if (data == null) {
			row = "n";
		}
		return row;
	}

	@RequestMapping(value = "/productInsertSave", method = RequestMethod.POST)
	public String productInsertSave(Model model, @ModelAttribute Product product) {
		
		
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		
		dao.insertRow(product);
		
		
		return "index";
	}
	
	@RequestMapping(value = "/productList", method = RequestMethod.GET)
	public String productList(Locale locale, Model model) {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		ArrayList<Product> products = dao.selectAll();
		model.addAttribute("products", products);
		return "product/product_list";
	}
	
	@RequestMapping(value = "/productUpdateAjax", method = RequestMethod.POST)
	@ResponseBody
	public String productUpdateAjax(@RequestParam String code, int stock) {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		
		product.setCode(code);
		product.setStock(stock);
		int result = dao.updateAjax(product);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}

	@RequestMapping(value = "/productDeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String productDeleteAjax(@RequestParam String code) {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		int result = dao.deleteAjax(code);
		System.out.println(result);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}


	}
		
	@RequestMapping(value = "/productUpdate", method = RequestMethod.GET)
    public String productUpdate(Model model, @RequestParam String code, HttpSession session) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		product = dao.selectOne(code);
							
		model.addAttribute("product",product);
    	return "product/product_update";
    }
	
	@RequestMapping(value = "/productUpdateSave", method = RequestMethod.POST)
    public String productUpdateSave( Model model,HttpSession session, @ModelAttribute Product product) throws IOException {  
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
    	
    	
    	dao.updateRow(product);    	
    	return "redirect:productList";
	}
	
	@RequestMapping(value = "/venderInsert", method = RequestMethod.GET)
	public String venderInsert() {
		
		
		return "product/vender_insert";
	}
	
	@RequestMapping(value = "/v_codeConfirmAjax", method = RequestMethod.POST)
	@ResponseBody
	public String v_codeConfirmAjax(@RequestParam String code) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		Vender data = dao.v_selectOne(code);

		String row = "y";
		if (data == null) {
			row = "n";
		}
		return row;
	}
	
	@RequestMapping(value = "/venderInsertSave", method = RequestMethod.POST)
	public String venderInsertSave(Model model, @ModelAttribute Vender vender) {
		
		
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		
		dao.v_insertRow(vender);
		
		
		return "index";
	}
	
	@RequestMapping(value = "/venderList", method = RequestMethod.GET)
	public String venderList(Locale locale, Model model) {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		ArrayList<Vender> venders = dao.v_selectAll();
		model.addAttribute("venders", venders);
		return "product/vender_list";
	}
	
		
	@RequestMapping(value = "/venderDeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String venderDeleteAjax(@RequestParam String code) {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		int result = dao.v_deleteAjax(code);
		System.out.println(result);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}
		
		
	}
	
	
	@RequestMapping(value = "/venderUpdate", method = RequestMethod.GET)
    public String venderUpdate(Model model, @RequestParam String code, HttpSession session) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		vender = dao.v_selectOne(code);
							
		model.addAttribute("vender",vender);
    	return "product/vender_update";
    }
	
	@RequestMapping(value = "/venderUpdateSave", method = RequestMethod.POST)
    public String venderUpdateSave( Model model,HttpSession session, @ModelAttribute Vender vender) throws IOException {  
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
    	
    	
    	dao.v_updateRow(vender);    	
    	return "redirect:venderList";
	}
	
}
