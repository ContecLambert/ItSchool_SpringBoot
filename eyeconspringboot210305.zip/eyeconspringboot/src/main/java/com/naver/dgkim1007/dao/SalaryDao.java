package com.naver.dgkim1007.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.naver.dgkim1007.entities.Salary;
import com.naver.dgkim1007.entities.SalaryRoll;
import com.naver.dgkim1007.entities.SalaryRollViewToBean;

@Mapper
@Repository
public interface SalaryDao {
	public Salary selectOne(String empno) throws Exception;

	public int insertRow(Salary salary);
	
	public int insertSalaryRoll(SalaryRoll salaryroll);
	
	public ArrayList<SalaryRollViewToBean> selectsalaryRollView(HashMap yyyymm);

	public int updateRow(Salary salary);

	public ArrayList<Salary> selectAll();
	
	public ArrayList<Salary> selectTaxYes();
	
	public int updateAjax(Salary salary);

	public int deleteAjax(String empno);
	
	public int salaryRollDeletebefore(HashMap yyyymm);
	
	public int empnoConfirmAjax(Salary salary);

	public int deleteRow(int empno);
	
//	public ArrayList<Salary> selectPageList(SalaryPaging salarypaging);
	
//	public ArrayList<Salary> findListSalary(SalaryPaging salarypaging);
	
	public int selectCountFirst();
	
//	public int selectCount(SalaryPaging salarypaging);
	
	public void addHit(int empno);
	
	public int insertReplyRow(Salary salary);

//	public int selectMaxStep(int b_ref);
	
	
}