package com.naver.dgkim1007.entities;

import org.springframework.stereotype.Component;

@Component
public class Balance {
	private String newyyyy;
	private String yyyy;
	private String vendcode;
	private String vendname;
	private int preyybalance;
	private int prebalance01;
	private int prebalance02;
	private int prebalance03;
	private int prebalance04;
	private int prebalance05;
	private int prebalance06;
	private int prebalance07;
	private int prebalance08;
	private int prebalance09;
	private int prebalance10;
	private int prebalance11;
	private int prebalance12;
	private int deal01;
	private int deal02;
	private int deal03;
	private int deal04;
	private int deal05;
	private int deal06;
	private int deal07;
	private int deal08;
	private int deal09;
	private int deal10;
	private int deal11;
	private int deal12;
	private int pay01;
	private int pay02;
	private int pay03;
	private int pay04;
	private int pay05;
	private int pay06;
	private int pay07;
	private int pay08;
	private int pay09;
	private int pay10;
	private int pay11;
	private int pay12;
	private int balance01;
	private int balance02;
	private int balance03;
	private int balance04;
	private int balance05;
	private int balance06;
	private int balance07;
	private int balance08;
	private int balance09;
	private int balance10;
	private int balance11;
	private int balance12;
	private int balance;
	private int paytot;
	private int dealtot;
	public String getNewyyyy() {
		return newyyyy;
	}
	public void setNewyyyy(String newyyyy) {
		this.newyyyy = newyyyy;
	}
	public String getYyyy() {
		return yyyy;
	}
	public void setYyyy(String yyyy) {
		this.yyyy = yyyy;
	}
	public String getVendcode() {
		return vendcode;
	}
	public void setVendcode(String vendcode) {
		this.vendcode = vendcode;
	}
	public String getVendname() {
		return vendname;
	}
	public void setVendname(String vendname) {
		this.vendname = vendname;
	}
	public int getPreyybalance() {
		return preyybalance;
	}
	public void setPreyybalance(int preyybalance) {
		this.preyybalance = preyybalance;
	}
	public int getPrebalance01() {
		return prebalance01;
	}
	public void setPrebalance01(int prebalance01) {
		this.prebalance01 = prebalance01;
	}
	public int getPrebalance02() {
		return prebalance02;
	}
	public void setPrebalance02(int prebalance02) {
		this.prebalance02 = prebalance02;
	}
	public int getPrebalance03() {
		return prebalance03;
	}
	public void setPrebalance03(int prebalance03) {
		this.prebalance03 = prebalance03;
	}
	public int getPrebalance04() {
		return prebalance04;
	}
	public void setPrebalance04(int prebalance04) {
		this.prebalance04 = prebalance04;
	}
	public int getPrebalance05() {
		return prebalance05;
	}
	public void setPrebalance05(int prebalance05) {
		this.prebalance05 = prebalance05;
	}
	public int getPrebalance06() {
		return prebalance06;
	}
	public void setPrebalance06(int prebalance06) {
		this.prebalance06 = prebalance06;
	}
	public int getPrebalance07() {
		return prebalance07;
	}
	public void setPrebalance07(int prebalance07) {
		this.prebalance07 = prebalance07;
	}
	public int getPrebalance08() {
		return prebalance08;
	}
	public void setPrebalance08(int prebalance08) {
		this.prebalance08 = prebalance08;
	}
	public int getPrebalance09() {
		return prebalance09;
	}
	public void setPrebalance09(int prebalance09) {
		this.prebalance09 = prebalance09;
	}
	public int getPrebalance10() {
		return prebalance10;
	}
	public void setPrebalance10(int prebalance10) {
		this.prebalance10 = prebalance10;
	}
	public int getPrebalance11() {
		return prebalance11;
	}
	public void setPrebalance11(int prebalance11) {
		this.prebalance11 = prebalance11;
	}
	public int getPrebalance12() {
		return prebalance12;
	}
	public void setPrebalance12(int prebalance12) {
		this.prebalance12 = prebalance12;
	}
	public int getDeal01() {
		return deal01;
	}
	public void setDeal01(int deal01) {
		this.deal01 = deal01;
	}
	public int getDeal02() {
		return deal02;
	}
	public void setDeal02(int deal02) {
		this.deal02 = deal02;
	}
	public int getDeal03() {
		return deal03;
	}
	public void setDeal03(int deal03) {
		this.deal03 = deal03;
	}
	public int getDeal04() {
		return deal04;
	}
	public void setDeal04(int deal04) {
		this.deal04 = deal04;
	}
	public int getDeal05() {
		return deal05;
	}
	public void setDeal05(int deal05) {
		this.deal05 = deal05;
	}
	public int getDeal06() {
		return deal06;
	}
	public void setDeal06(int deal06) {
		this.deal06 = deal06;
	}
	public int getDeal07() {
		return deal07;
	}
	public void setDeal07(int deal07) {
		this.deal07 = deal07;
	}
	public int getDeal08() {
		return deal08;
	}
	public void setDeal08(int deal08) {
		this.deal08 = deal08;
	}
	public int getDeal09() {
		return deal09;
	}
	public void setDeal09(int deal09) {
		this.deal09 = deal09;
	}
	public int getDeal10() {
		return deal10;
	}
	public void setDeal10(int deal10) {
		this.deal10 = deal10;
	}
	public int getDeal11() {
		return deal11;
	}
	public void setDeal11(int deal11) {
		this.deal11 = deal11;
	}
	public int getDeal12() {
		return deal12;
	}
	public void setDeal12(int deal12) {
		this.deal12 = deal12;
	}
	public int getPay01() {
		return pay01;
	}
	public void setPay01(int pay01) {
		this.pay01 = pay01;
	}
	public int getPay02() {
		return pay02;
	}
	public void setPay02(int pay02) {
		this.pay02 = pay02;
	}
	public int getPay03() {
		return pay03;
	}
	public void setPay03(int pay03) {
		this.pay03 = pay03;
	}
	public int getPay04() {
		return pay04;
	}
	public void setPay04(int pay04) {
		this.pay04 = pay04;
	}
	public int getPay05() {
		return pay05;
	}
	public void setPay05(int pay05) {
		this.pay05 = pay05;
	}
	public int getPay06() {
		return pay06;
	}
	public void setPay06(int pay06) {
		this.pay06 = pay06;
	}
	public int getPay07() {
		return pay07;
	}
	public void setPay07(int pay07) {
		this.pay07 = pay07;
	}
	public int getPay08() {
		return pay08;
	}
	public void setPay08(int pay08) {
		this.pay08 = pay08;
	}
	public int getPay09() {
		return pay09;
	}
	public void setPay09(int pay09) {
		this.pay09 = pay09;
	}
	public int getPay10() {
		return pay10;
	}
	public void setPay10(int pay10) {
		this.pay10 = pay10;
	}
	public int getPay11() {
		return pay11;
	}
	public void setPay11(int pay11) {
		this.pay11 = pay11;
	}
	public int getPay12() {
		return pay12;
	}
	public void setPay12(int pay12) {
		this.pay12 = pay12;
	}
	public int getBalance01() {
		return balance01;
	}
	public void setBalance01(int balance01) {
		this.balance01 = balance01;
	}
	public int getBalance02() {
		return balance02;
	}
	public void setBalance02(int balance02) {
		this.balance02 = balance02;
	}
	public int getBalance03() {
		return balance03;
	}
	public void setBalance03(int balance03) {
		this.balance03 = balance03;
	}
	public int getBalance04() {
		return balance04;
	}
	public void setBalance04(int balance04) {
		this.balance04 = balance04;
	}
	public int getBalance05() {
		return balance05;
	}
	public void setBalance05(int balance05) {
		this.balance05 = balance05;
	}
	public int getBalance06() {
		return balance06;
	}
	public void setBalance06(int balance06) {
		this.balance06 = balance06;
	}
	public int getBalance07() {
		return balance07;
	}
	public void setBalance07(int balance07) {
		this.balance07 = balance07;
	}
	public int getBalance08() {
		return balance08;
	}
	public void setBalance08(int balance08) {
		this.balance08 = balance08;
	}
	public int getBalance09() {
		return balance09;
	}
	public void setBalance09(int balance09) {
		this.balance09 = balance09;
	}
	public int getBalance10() {
		return balance10;
	}
	public void setBalance10(int balance10) {
		this.balance10 = balance10;
	}
	public int getBalance11() {
		return balance11;
	}
	public void setBalance11(int balance11) {
		this.balance11 = balance11;
	}
	public int getBalance12() {
		return balance12;
	}
	public void setBalance12(int balance12) {
		this.balance12 = balance12;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getPaytot() {
		return paytot;
	}
	public void setPaytot(int paytot) {
		this.paytot = paytot;
	}
	public int getDealtot() {
		return dealtot;
	}
	public void setDealtot(int dealtot) {
		this.dealtot = dealtot;
	}
	
	
	
}
