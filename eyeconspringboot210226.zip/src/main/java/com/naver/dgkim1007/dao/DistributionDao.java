package com.naver.dgkim1007.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.naver.dgkim1007.entities.Balance;

@Mapper
@Repository
public interface DistributionDao {
		
	public Balance selectOne(String yyyy) throws Exception;

	public int insertRow(Balance balance);

	public int updateRow(Balance balance);

	public ArrayList<Balance> selectAll();

	public int updateAjax(Balance balance);

	public int deleteAjax(Balance balance);
}