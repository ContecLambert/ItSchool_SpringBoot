package com.naver.dgkim1007;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.naver.dgkim1007.dao.DistributionDao;
import com.naver.dgkim1007.entities.Balance;

@Controller
public class DistributionController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	Balance balance;
		
	@RequestMapping(value = "/balanceInsert", method = RequestMethod.GET)
	public String balanceInsert() {
		
		
		return "distribution/balance_insert";
	}
	
	@RequestMapping(value = "/balanceInsertSave", method = RequestMethod.POST)
	public String balanceInsertSave(Model model, @ModelAttribute Balance balance) {
		
		
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		
		dao.insertRow(balance);
		
		
		return "index";
	}
	
	@RequestMapping(value = "/vendcodeConfirmAjax", method = RequestMethod.POST)
	@ResponseBody
	public String vendcodeConfirmAjax(@RequestParam String vendcode) throws Exception {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		Balance data = dao.selectOne(vendcode);
		
		String row = "y";
		if (data == null) {
			row = "n";
		}
		return row;
	}
	
	@RequestMapping(value = "/balanceSearch", method = RequestMethod.GET)
	public String balanceSearch(Locale locale, Model model) {
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
		SimpleDateFormat df_y = new SimpleDateFormat("yyyy");
		
		int today_year =  Integer.parseInt(df_y.format(date));
		int start = today_year-2;
				
		int years[] = new int[5];
		
		for(int i= 0;i < years.length; i++) {
			years[i] = start++;
		}
		
		model.addAttribute("today_year",today_year);
		model.addAttribute("years",years);
		
		return "distribution/balace_search";
	}
	
	@RequestMapping(value = "/balanceList", method = RequestMethod.POST)
	public String balanceList(Locale locale, Model model) {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		ArrayList<Balance> balances = dao.selectAll();
		
		model.addAttribute("balances", balances);
		return "distribution/balance_list";
	}
	
	@RequestMapping(value = "/balanceUpdateAjax", method = RequestMethod.POST)
	@ResponseBody
	public String balanceUpdateAjax(@RequestParam String yyyy, int bal) {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		balance.setYyyy(yyyy);
		balance.setBalance(bal);
		int result = dao.updateAjax(balance);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}

	@RequestMapping(value = "/balanceDeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String balanceDeleteAjax(@RequestParam String yyyy, String vendcode) {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		balance.setYyyy(yyyy);
		balance.setVendcode(vendcode);
		int result = dao.deleteAjax(balance);
		System.out.println(result);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}


	}
	
	@RequestMapping(value = "/balanceUpdate", method = RequestMethod.GET)
	public String balanceUpdate(Model model, @RequestParam String vendcode, HttpSession session) throws Exception {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		balance = dao.selectOne(vendcode);
		
		model.addAttribute("balance",balance);
		return "distribution/balance_update";
	}
	
	@RequestMapping(value = "/balanceUpdateSave", method = RequestMethod.POST)
	public String vbalanceUpdateSave( Model model,HttpSession session, @ModelAttribute Balance balance) throws IOException {  
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		
		
		dao.updateRow(balance);    	
		return "redirect:balanceList";
	}
}
