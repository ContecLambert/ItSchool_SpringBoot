package com.naver.dgkim1007;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.naver.dgkim1007.dao.BuyDao;
import com.naver.dgkim1007.dao.DistributionDao;
import com.naver.dgkim1007.dao.ProductDao;
import com.naver.dgkim1007.entities.Balance;
import com.naver.dgkim1007.entities.Buy;
import com.naver.dgkim1007.entities.Product;
import com.naver.dgkim1007.entities.Vender;

@Controller
public class DistributionController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	Balance balance;
	@Autowired
	Buy buy;
	@Autowired
	Vender vender;
	
	@RequestMapping(value = "/balanceInsert", method = RequestMethod.GET)
	public String balanceInsert() {
		
		
		return "distribution/balance_insert";
	}
	
	@RequestMapping(value = "/balanceInsertSave", method = RequestMethod.POST)
	public String balanceInsertSave(Model model, @ModelAttribute Balance balance) {
		
		
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		
		dao.insertRow(balance);
		
		
		return "index";
	}
	
	@RequestMapping(value = "/vendcodeConfirmAjax", method = RequestMethod.POST)
	@ResponseBody
	public String vendcodeConfirmAjax(@RequestParam String vendcode) throws Exception {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		Balance data = dao.selectOne(vendcode);
		
		String row = "y";
		if (data == null) {
			row = "n";
		}
		return row;
	}
	
	@RequestMapping(value = "/balanceSearch", method = RequestMethod.GET)
	public String balanceSearch(Locale locale, Model model) {
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
		SimpleDateFormat df_y = new SimpleDateFormat("yyyy");
		
		int today_year =  Integer.parseInt(df_y.format(date));
		int start = today_year-2;
				
		int years[] = new int[5];
		
		for(int i= 0;i < years.length; i++) {
			years[i] = start++;
		}
		
		model.addAttribute("today_year",today_year);
		model.addAttribute("years",years);
		
		return "distribution/balace_search";
	}
	
	@RequestMapping(value = "/balanceList", method = RequestMethod.GET)
	public String balanceList(Locale locale, Model model) {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		ArrayList<Balance> balances = dao.selectAll();
		
		model.addAttribute("balances", balances);
		return "distribution/balance_list";
	}
	
	@RequestMapping(value = "/balanceUpdateAjax", method = RequestMethod.POST)
	@ResponseBody
	public String balanceUpdateAjax(@RequestParam String yyyy, int bal) {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		balance.setYyyy(yyyy);
		balance.setBalance(bal);
		int result = dao.updateAjax(balance);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}

	@RequestMapping(value = "/balanceDeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String balanceDeleteAjax(@RequestParam String yyyy, String vendcode) {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		balance.setYyyy(yyyy);
		balance.setVendcode(vendcode);
		int result = dao.deleteAjax(balance);
		System.out.println(result);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}


	}
	
	
	@RequestMapping(value = "/balanceUpdate", method = RequestMethod.GET)
	public String balanceUpdate(Model model, @RequestParam String vendcode, HttpSession session) throws Exception {
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		balance = dao.selectOne(vendcode);
		
		model.addAttribute("balance",balance);
		return "distribution/balance_update";
	}
	
	@RequestMapping(value = "/balanceUpdateSave", method = RequestMethod.POST)
	public String vbalanceUpdateSave( Model model,HttpSession session, @ModelAttribute Balance balance) throws IOException {  
		DistributionDao dao = sqlSession.getMapper(DistributionDao.class);
		
		
		dao.updateRow(balance);    	
		return "redirect:balanceList";
	}
	
	@RequestMapping(value = "/buyInsert", method = RequestMethod.GET)
	public String buyInsert(Model model) {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		BuyDao daobuy = sqlSession.getMapper(BuyDao.class);
		
		ArrayList<Product> products = dao.selectAll();
		ArrayList<Vender> venders = dao.v_selectAll();
		
		Date date = new Date();
		SimpleDateFormat year_date = new SimpleDateFormat("yyyy");
		SimpleDateFormat MM_date = new SimpleDateFormat("MM");
		SimpleDateFormat dd_date = new SimpleDateFormat("dd");
		
		String yyyy = year_date.format(date);
		String mm = MM_date.format(date);
		String dd = dd_date.format(date);
	
		buy.setYyyy(yyyy);
		buy.setMm(mm);
		buy.setDd(dd);
		model.addAttribute(buy);
		
		model.addAttribute("venders",venders);
		model.addAttribute("products",products);
		
		ArrayList<Buy> buys = daobuy.selectBuyRollup();
		model.addAttribute("buys",buys);
		
		
		return "distribution/buy_insert";
	}
	
	@RequestMapping(value = "/productSelectedAjax", method = RequestMethod.POST)
	@ResponseBody
	public Product productSelectedAjax(@RequestParam String code) throws Exception {
		ProductDao dao = sqlSession.getMapper(ProductDao.class);
		Product product = dao.selectOne(code);
		return product;
		
	}
	
	@RequestMapping(value = "/buyNew", method = RequestMethod.POST)
	@ResponseBody
	public Buy buyNew(@RequestParam String vendcode) throws Exception {
		BuyDao dao = sqlSession.getMapper(BuyDao.class);
		ProductDao daovender = sqlSession.getMapper(ProductDao.class);
		Date date = new Date();
		SimpleDateFormat year_date = new SimpleDateFormat("yyyy");
		SimpleDateFormat MM_date = new SimpleDateFormat("MM");
		SimpleDateFormat dd_date = new SimpleDateFormat("dd");
		
		String yyyy = year_date.format(date);
		String mm = MM_date.format(date);
		String dd = dd_date.format(date);
		
		vender = daovender.v_selectOne(vendcode);
		buy.setVendcode(vendcode);
		buy.setVendname(vender.getName());
		buy.setYyyy(yyyy);
		buy.setMm(mm);
		buy.setDd(dd);
		int no = dao.getMaxNo(buy);
		int hang = dao.getMaxHang(buy);
		buy.setNo(no);
		buy.setHang(hang);
		return buy;
	}
	
	@RequestMapping(value = "/buyInsertSave", method = RequestMethod.POST)
	public String buyInsertSave(Model model, @ModelAttribute Buy buy) {
		BuyDao dao = sqlSession.getMapper(BuyDao.class);
		
		dao.insertRow(buy);
		ProductDao daoproduct = sqlSession.getMapper(ProductDao.class);
		ArrayList<Product> products = daoproduct.selectAll();
		ArrayList<Vender> venders = daoproduct.v_selectAll();
		
		model.addAttribute("venders",venders);
		model.addAttribute("products",products);
		System.out.println(dao.getMaxHang(buy));
		buy.setHang(dao.getMaxHang(buy));
		
		model.addAttribute("buy",buy);
		ArrayList<Buy> buyrollups = dao.selectBuyRollup();
		model.addAttribute("buyrolluos",buyrollups);
		
		
		return "redirect:buyInsert";
	}
	
}
