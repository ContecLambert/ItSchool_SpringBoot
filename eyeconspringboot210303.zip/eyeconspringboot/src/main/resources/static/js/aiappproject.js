function confirm_email() {
	var yncheck = $('.confirmyn').val();
	if (yncheck == "n") {
		msg = "email 중복 검사를 하세요";
		$('.description').text(msg);
		$('.modal').modal('show');
	}
}

function confirm_empno() {
	var yncheck = $('.empnoconfirmyn').val();
	if (yncheck == "n") {
		msg = "사원번호 중복 검사를 하세요";
		$('.description').text(msg);
		$('.modal').modal('show');
	}
}
var index = 0;
window.onload = function(){
	$('.ui.dropdown').dropdown();
	slideShow();
}

function slideShow(){
	var i;
	var x =document.getElementsByClassName("slide1");
	for(i=0;i<x.length;i++){
		x[i].style.display="none";
	}
	index++;
	if(index>x.length){
		index=1;
	}
	x[index-1].style.display="block";
	setTimeout(slideShow,4000);
}
tinymce.init({
	selector: 'textarea',
	plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
	toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
	toolbar_mode: 'floating',
	tinycomments_mode: 'embedded',
	tinycomments_author: 'Author name',
	branding: false
});

function zipcodeFind(){
  new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.
                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var fullAddr = ''; // 최종 주소 변수
                var extraAddr = ''; // 조합형 주소 변수
                // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    fullAddr = data.roadAddress;
                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    fullAddr = data.jibunAddress;
                }
                // 사용자가 선택한 주소가 도로명 타입일때 조합한다.
                if(data.userSelectedType === 'R'){
                    //법정동명이 있을 경우 추가한다.
                    if(data.bname !== ''){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있을 경우 추가한다.
                    if(data.buildingName !== ''){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
                    fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');
                }
                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('zipcode').value = data.zonecode; //5자리 새우편번호 사용
                document.getElementById('addr1').value = fullAddr;
                // 커서를 상세주소 필드로 이동한다.
                document.getElementById('addr2').focus();
            }
        }).open();
 }

$(document).ready(function() {
	$('.confirm').on('click', function() {
		var email = $('#email').val();
		if (email == "") {
			$('.description').text("E-mail을 입력하세요");
			$('.modal').modal('show');
			return;
		} else {
			var email = email;
			$.ajax({
				type: 'POST',
				data: {
					email: email
				},
				datatype: 'json',
				url: 'emailConfirmAjax',
				success: function(data) {
					var msg = "";
					if (data == "y") {
						msg = "사용중인 email입니다";
						$('.confirmyn').val('n');
						$('.description').text(msg);
						$('.modal').modal('show');
						$('#email').val('');
						$('#email').focus();
					} else {
						$('.confirmyn').val('y');
						msg = "사용 가능한 email입니다";
						$('.description').text(msg);
						$('.modal').modal('show');
					}

				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		}
	});
	$('.empnoconfirm').on('click', function() {
		var empno = $('#empno').val();
		if (empno == "") {
			$('.description').text("사원 번호를 입력하세요.");
			$('.modal').modal('show');
			return;
		} else {
			var empno = empno;
			$.ajax({
				type: 'POST',
				data: {
					empno: empno
				},
				datatype: 'json',
				url: 'empnoConfirmAjax',
				success: function(data) {
					var msg = "";
					if (data == "y") {
						msg = "사용중인 사원 번호입니다";
						$('.empnoconfirmyn').val('n');
						$('.description').text(msg);
						$('.modal').modal('show');
						$('#empno').val('');
						$('#empno').focus();
					} else {
						$('.empnoconfirmyn').val('y');
						msg = "사용 가능한 사원 번호입니다";
						$('.description').text(msg);
						$('.modal').modal('show');
					}

				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		}
	});
	
	$('.codeconfirm').on('click', function() {
      var code = $('#code').val();
      if (code == "") {
         $('.description').text("상품번호를 입력하세요");
         $('.modal').modal('show');
         return;
      } else {
         var code = code;
         $.ajax({
            type: 'POST',
            data: {
               code: code
            },
            datatype: 'json',
            url: 'codeConfirmAjax',
            success: function(data) {
               var msg = "";
               if (data == "y") {
                  msg = "사용중인 상품번호입니다";
                  $('.confirmyn').val('n');
                  $('.description').text(msg);
                  $('.modal').modal('show');
                  $('#code').val('');
                  $('#code').focus();
               } else {
                  $('.confirmyn').val('y');
                  msg = "사용 가능한 상품번호입니다";
                  $('.description').text(msg);
                  $('.modal').modal('show');
               }

            },
            error: function(xhr, status, error) {
               alert('ajax error : ' + xhr.status);
            }
         });
      }
  	});

	$('.vendconfirm').on('click', function() {
      var code = $('#code').val();
      if (code == "") {
         $('.description').text("거래처 번호를 입력하세요");
         $('.modal').modal('show');
         return;
      } else {
         var code = code;
         $.ajax({
            type: 'POST',
            data: {
               code: code
            },
            datatype: 'json',
            url: 'v_codeConfirmAjax',
            success: function(data) {
               var msg = "";
               if (data == "y") {
                  msg = "사용중인 거래처 번호입니다";
                  $('.description').text(msg);
                  $('.modal').modal('show');
                  $('#code').val('');
                  $('#code').focus();
               } else {
                  msg = "사용 가능한 상품번호입니다";
                  $('.description').text(msg);
                  $('.modal').modal('show');
               }

            },
            error: function(xhr, status, error) {
               alert('ajax error : ' + xhr.status);
            }
         });
      }
   	});
	$('.balanceconfirm').on('click', function() {
      var vendcode = $('#vendcode').val();
      if (vendcode == "") {
         $('.description').text("거래처 번호를 입력하세요");
         $('.modal').modal('show');
         return;
      } else {
         var vendcode = vendcode;
         $.ajax({
            type: 'POST',
            data: {
               vendcode: vendcode
            },
            datatype: 'json',
            url: 'vendcodeConfirmAjax',
            success: function(data) {
               var msg = "";
               if (data == "y") {
                  msg = "사용중인 판매자 번호입니다";
                  $('.description').text(msg);
                  $('.modal').modal('show');
                  $('#vendcode').val('');
                  $('#vendcode').focus();
               } else {
                  msg = "사용 가능한 판매자 번호입니다";
                  $('.description').text(msg);
                  $('.modal').modal('show');
               }

            },
            error: function(xhr, status, error) {
               alert('ajax error : ' + xhr.status);
            }
         });
      }
   });
	$(".attachbtn").on('click', function() {
		$('#b_attachfile').click();
		$('#b_attachfile').change(function() {
			var filename = $('#b_attachfile').val();
			$('.b_attachname').attr('value', filename);
		});
	});

	/*	$('#b_attachfile').on('change',function(event){
			alert($('#b_attach').val());
	//		var attachpath = URL.createObjectURL(event.target.files[0]);		
		})*/


	$("#viewphoto").on('click', function() {
		$('input[type=file]').click();
		return false;
	});

	$("#imgfile").on('change', function(event) {
		var imgpath = URL.createObjectURL(event.target.files[0]);
		$('#viewphoto').attr('src', imgpath)
	});

	$('#memberexample').DataTable({
		deferRender: true,
		scrollY: 300,
		scrollCollapse: true,
		scroller: true
	});
	
	$('#salaryexample').DataTable({
		deferRender: true,
		scrollY: 300,
		scrollCollapse: true,
		scroller: true,
		autoWidth: true
	});
	
	$('#salaryrolllist').DataTable({
		aaSorting: [],
		deferRender: true,
		scrollY: 300,
		scrollCollapse: true,
		scroller: true,
		autoWidth: true
	});

	$('#productexample').DataTable( {
		   deferRender:    true,
		   scrollY:        360,
		   scrollCollapse: true
	});
	
	$('#venderexample').DataTable( {
		   deferRender:    true,
		   scrollY:        360,
		   scrollCollapse: true
	} );
	
	$('#balanceexample').DataTable( {
		   deferRender:    true,
		   scrollY:        360,
		   scrollCollapse: true,
		   aaSorting: []
	} );
	
	$('#buyexample').DataTable( {
		   deferRender:    true,
		   scrollY:        360,
		   scrollCollapse: true,
		   aaSorting: []
	} );

	$(document).on('click', '#memberexample td #editbtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var email = td.eq(1).text();
		var level = td.eq(4).children().val();

		$.ajax({
			type: 'POST',
			data: { email: email, level: level },
			datatype: 'json',
			url: 'memberUpdateAjax',
			success: function(data) {
				if (data == 'y') {
					$('#resultmessage').text("수정되었습니다.");
				} else {
					$('#resultmessage').text("수정되지않았습니다.");
				}
				$('#successmsg').css('display', "block")
					.delay(1200).queue(function() {
						$('#successmsg').css('display', "none").dequeue();
					});
			},
			error: function(xhr, status, error) {
				alert('ajax error : ' + xhr.status + error);
			}
		});
	});

	$(document).on('click', '#memberexample td #deletebtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var email = td.eq(1).text();

		$('.mini.ui.modal.delete').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { email: email },
				datatype: 'json',
				url: 'memberDeleteAjax',
				success: function(data) {
					if (data == 'y') {
						row.remove();
						$('#resultmessage').text("삭제되었습니다.");
					} else {
						$('#resultmessage').text("삭제되지않았습니다.");
					}
					$('#successmsg').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmsg').css('display', "none").dequeue();
						});
					$('.mini.ui.modal.delete').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		});
	});
	
	$(document).on('click', '#salaryexample td #yneditbtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var empno = td.eq(0).children().children().text();
		var yn = td.eq(10).children().val();

		$.ajax({
			type: 'POST',
			data: { empno: empno, yn: yn },
			datatype: 'json',
			url: 'salaryUpdateAjax',
			success: function(data) {
				if (data == 'y') {
					$('#resultmessage').text("수정되었습니다.");
				} else {
					$('#resultmessage').text("수정되지않았습니다.");
				}
				$('#successmsg').css('display', "block")
					.delay(1200).queue(function() {
						$('#successmsg').css('display', "none").dequeue();
					});
			},
			error: function(xhr, status, error) {
				alert('ajax error : ' + xhr.status + error);
			}
		});
	});

	$(document).on('click', '#salaryexample td #salarydeletebtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var empno = td.eq(0).children().text();

		$('.mini.ui.modal.delete').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { empno: empno },
				datatype: 'json',
				url: 'salaryDeleteAjax',
				success: function(data) {
					if (data == 'y') {
						row.remove();
						$('#resultmessage').text("삭제되었습니다.");
					} else {
						$('#resultmessage').text("삭제되지않았습니다.");
					}
					$('#successmsg').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmsg').css('display', "none").dequeue();
						});
					$('.mini.ui.modal.delete').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		});
	});
	
	$(document).on('click', '#productexample td #editbtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var code = td.eq(0).children().children().text();
		var stock = td.eq(15).children().val();
		$.ajax({
			type: 'POST',
			data: { code: code, stock: stock },
			datatype: 'json',
			url: 'productUpdateAjax',
			success: function(data) {
				if (data == 'y') {
					$('#resultmessage').text("수정되었습니다.");
				} else {
					$('#resultmessage').text("수정되지않았습니다.");
				}
				$('#successmsg').css('display', "block")
					.delay(1200).queue(function() {
						$('#successmsg').css('display', "none").dequeue();
					});
			},
			error: function(xhr, status, error) {
				alert('ajax error : ' + xhr.status + error);
			}
		});
	});

	$(document).on('click', '#productexample td #deletebtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var code = td.eq(0).children().children().text();
		
		$('.mini.ui.modal.delete').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { code: code},
				datatype: 'json',
				url: 'productDeleteAjax',
				success: function(data) {
					if (data == 'y') {
						row.remove();
						$('#resultmessage').text("삭제되었습니다.");
					} else {
						$('#resultmessage').text("삭제되지않았습니다.");
					}
					$('#successmsg').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmsg').css('display', "none").dequeue();
						});
					$('.mini.ui.modal.delete').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		});
	});
	
	$(document).on('click', '#venderexample td #deletebtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var code = td.eq(0).children().children().text();
		
		$('.mini.ui.modal.delete').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { code: code},
				datatype: 'json',
				url: 'venderDeleteAjax',
				success: function(data) {
					if (data == 'y') {
						row.remove();
						$('#resultmessage').text("삭제되었습니다.");
					} else {
						$('#resultmessage').text("삭제되지않았습니다.");
					}
					$('#successmsg').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmsg').css('display', "none").dequeue();
						});
					$('.mini.ui.modal.delete').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		});
	});
	
	$(document).on('click', '#balanceexample td #editbtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var yyyy = td.eq(0).text();
		var bal = td.eq(4).children().val();
		$.ajax({
			type: 'POST',
			data: { yyyy: yyyy, bal: bal },
			datatype: 'json',
			url: 'balanceUpdateAjax',
			success: function(data) {
				if (data == 'y') {
					$('#resultmessage').text("수정되었습니다.");
				} else {
					$('#resultmessage').text("수정되지않았습니다.");
				}
				$('#successmsg').css('display', "block")
					.delay(1200).queue(function() {
						$('#successmsg').css('display', "none").dequeue();
					});
			},
			error: function(xhr, status, error) {
				alert('ajax error : ' + xhr.status + error);
			}
		});
	});

	$(document).on('click', '#balanceexample td #deletebtn', function() {
		var row = $(this).closest('tr'); // 현재 선택된 tr을 row로 보겠다
		var td = row.children();
		var yyyy = td.eq(0).text();
		var vendcode = td.eq(1).children().children().text();
		
		$('.mini.ui.modal.delete').modal('show');

		$('#deleteok').on('click', function() {
			$.ajax({
				type: 'POST',
				data: { yyyy: yyyy, vendcode:vendcode },
				datatype: 'json',
				url: 'balanceDeleteAjax',
				success: function(data) {
					if (data == 'y') {
						row.remove();
						$('#resultmessage').text("삭제되었습니다.");
					} else {
						$('#resultmessage').text("삭제되지않았습니다.");
					}
					$('#successmsg').css('display', "block")
						.delay(1200).queue(function() {
							$('#successmsg').css('display', "none").dequeue();
						});
					$('.mini.ui.modal.delete').modal('hide');
				},
				error: function(xhr, status, error) {
					alert('ajax error : ' + xhr.status + error);
				}
			});
		});
	});
	
	$('.boarddelete').on('click', function() {
		$('.mini.ui.modal.boardmodal').modal('show');

		$('.deleteok').on('click', function() {
			$('.mini.ui.modal.boardmodal').modal('hide');
			var b_seq = $('#hidden_seq').val();
			document.location.href="boardDelete?b_seq="+b_seq;
		});

		$('.cancleok').on('click', function() {
			$('.mini.ui.modal.boardmodal').modal('hide');
			return;
		});
	});
	
	$('#taxcrtbtn').on('click', function() {
		$('.description').text("계산 버튼 누르면 기존 데이터는 삭제됩니다.")
		$('.mini.ui.modal.salarytax').modal('show');
		$('#salaryrolldeleteok').text("계산")
		$('#salaryrolldeleteok').on('click', function() {
			$('#salarytaxform').attr('action','salaryTaxRun');
			$('#salarytaxform').submit();
			
		});

		$('#salaryrollcancleok').on('click', function() {
			$('.mini.ui.modal.boardmodal').modal('hide');
			return;
		});
	});

	$('#taxdelbtn').on('click', function() {
		$('.description').text("삭제하시겠습니까?")
		$('.mini.ui.modal.salarytax').modal('show');
		$('#salaryrolldeleteok').text("삭제")
		$('#salaryrolldeleteok').on('click', function() {
			$('#salarytaxform').attr('action','salaryTaxDelete');
			$('#salarytaxform').submit();
			
		});

		$('#salaryrollcancleok').on('click', function() {
			$('.mini.ui.modal.boardmodal').modal('hide');
			return;
		});
		
	});
	$("#selectproduct").on("change",function(){
      	var code = $("#selectproduct").val();
      	$.ajax({
        	 type: 'POST',
	         data: {code:code},
	         datatype: 'json',
	         url: 'productSelectedAjax',
	         contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
	         success: function(data) {
				$('#price').val(data.buyprice);
				$('#proname').val(data.name);
				$('#procode').val(data.code);
				$('#qty').focus();
	         },
	         error: function(xhr, status, error) {
	            alert('ajax error' + xhr.status);
	         }
      	});
   	});

	$("#selectvender").on("change",function(){
      	var vendcode = $("#selectvender").val();
      	$.ajax({
        	 type: 'POST',
	         data: {vendcode:vendcode},
	         datatype: 'json',
	         url: 'buyNew',
	         contentType: 'application/x-www-form-urlencoded; charset=euc-kr',
	         success: function(data) {
				$('#rigthvendname').val(data.vendname);
				$('#vendname').val(data.vendname);
				$('#yyyy').val(data.yyyy);
				$('#mm').val(data.mm);
				$('#dd').val(data.dd);
				$('#no').val(data.no);
				$('#hang').val(data.hang);
	         },
	         error: function(xhr, status, error) {
	            alert('ajax error' + xhr.status);
	         }
      	});
   	});
	
	$('#qty').keyup(function(){
		var price = $('#price').val();
		var qty = $(this).val();
		var total = price * qty;
		$('#total').val(total);
	});
	
	
	$('#buysavebtn').on('click', function() {
		var vendcode = $("#selectvender").val();
		if(vendcode == "0000"){
			$('.description').text("거래처를 선택하세요.")
			$('.mini.ui.modal.buy').modal('show');
			
			$('#buymodalsavebtn').on('click',function(){
				$('.mini.ui.modal.buy').modal('hide');
				return;	
			});
			return;
		}
		
		var code = $("#selectproduct").val();
		if(code == "0000000000000"){
			$('.description').text("상품을 선택하세요.")
			$('.mini.ui.modal.buy').modal('show');
			
			$('#buymodalsavebtn').on('click',function(){
				$('.mini.ui.modal.buy').modal('hide');
				return;	
			});
			return;
		}
		$('#buyinsertform').submit();
	});
	$('#findbtnclick').on('click',function(){
		var vendcode = $("#selectvenderfind").val();
		if(vendcode == "0000"){
			$('.description').text("거래처를 선택하세요.")
			$('.mini.ui.modal.buy').modal('show');
			
			$('#buymodalsavebtn').on('click',function(){
				$('.mini.ui.modal.buy').modal('hide');
				return;	
			});
			return;
		}
		$('#buyfindform').submit();
	});
	
	$("#selectvenderfind").on("change",function(){
		var vendname = $('#selectvenderfind option:selected').text();
		$('#hiddenvendname').val(vendname);
	});
	$("#buyfindtable").on("click","#buyitemrow","td",function(){
		var row = $(this).closest('tr');
		var td = row.children();
		var seq = td.eq(0).text();
		alert(seq);
	});
});