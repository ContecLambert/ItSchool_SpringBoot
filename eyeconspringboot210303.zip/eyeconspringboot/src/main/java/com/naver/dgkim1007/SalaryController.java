package com.naver.dgkim1007;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.naver.dgkim1007.dao.SalaryDao;
import com.naver.dgkim1007.entities.Salary;
import com.naver.dgkim1007.entities.SalaryRoll;
import com.naver.dgkim1007.entities.SalaryRollViewToBean;

@Controller
public class SalaryController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	Salary salary;
	@Autowired
	SalaryRoll salaryroll;

	@RequestMapping(value = "/salaryInsert", method = RequestMethod.GET)
	public String salaryInsert(Locale locale, Model model) {
		return "salary/salary_insert";
	}

	
	@RequestMapping(value = "/salaryInsertSave", method = RequestMethod.POST)
	public String salaryInsertSave(Model model, @ModelAttribute Salary salary) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		dao.insertRow(salary);
		
		return "index";
	}
	
	@RequestMapping(value = "/empnoConfirmAjax", method = RequestMethod.POST)
	@ResponseBody
	public String empnoConfirmAjax(@RequestParam String empno) throws Exception {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		Salary data = dao.selectOne(empno);

		String row = "y";
		if (data == null) {
			row = "n";
		}
		return row;
	}
	
	@RequestMapping(value = "/salaryList", method = RequestMethod.GET)
	public String salaryList(Locale locale, Model model) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		ArrayList<Salary> salarys = dao.selectAll();
		model.addAttribute("salarys", salarys);
		
		String arryns[] = new String[2];
		arryns[0] ="y";
		arryns[1] = "n";
		model.addAttribute("arryns", arryns);
		return "salary/salary_list";
	}
	
	@RequestMapping(value = "/salaryUpdate", method = RequestMethod.GET)
    public String salaryUpdate(Model model, @RequestParam String empno, HttpSession session) throws Exception {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		salary = dao.selectOne(empno);
							
		model.addAttribute("salary",salary);
    	return "salary/salary_update";
    }
	
	@RequestMapping(value = "/salaryUpdateSave", method = RequestMethod.POST)
    public String salaryUpdateSave( Model model,HttpSession session, @ModelAttribute Salary salary) throws IOException {  
    	SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
    	
    	
    	dao.updateRow(salary);    	
    	return "redirect:salaryList";
	}
	
	@RequestMapping(value = "/salaryUpdateAjax", method = RequestMethod.POST)
	@ResponseBody
	public String salaryUpdateAjax(@RequestParam String empno, String yn) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		salary.setEmpno(empno);;
		salary.setYn(yn);
		int result = dao.updateAjax(salary);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}
	
	@RequestMapping(value = "/salaryDeleteAjax", method = RequestMethod.POST)
	@ResponseBody
	public String salaryDeleteAjax(@RequestParam String empno) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		salary.setEmpno(empno);
		int result = dao.deleteAjax(empno);
		if (result > 0) {
			return "y";
		} else {
			return "n";
		}

	}
	
	@RequestMapping(value = "/salaryTax", method = RequestMethod.GET)
	public String salaryTax(Locale locale, Model model) {
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
		SimpleDateFormat df_y = new SimpleDateFormat("yyyy");
		
		int today_year =  Integer.parseInt(df_y.format(date));
		int start = today_year-2;
				
		int years[] = new int[5];
		
		for(int i= 0;i < years.length; i++) {
			years[i] = start++;
		}
		
		model.addAttribute("today_year",today_year);
		model.addAttribute("years",years);
		
		String today_month = String.format("%02d", cal.get(Calendar.MONTH) +1);
		
		
		String months[] = new String[] {"01","02","03","04","05","06","07","08","09","10","11","12"};
		model.addAttribute("today_month",today_month);
		model.addAttribute("months",months);
		
		
		
		return "salary/salary_tax";
	}


	@RequestMapping(value = "/salaryTaxRun", method = RequestMethod.POST)
	public String salaryTaxRun(Model model,@RequestParam String yyyy, String mm) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		ArrayList<Salary> salarys = dao.selectTaxYes();
		HashMap yyyymm = new HashMap();
		yyyymm.putIfAbsent("yyyy", yyyy);
		yyyymm.putIfAbsent("mm", mm);
		
		dao.salaryRollDeletebefore(yyyymm);
		
		for(Salary salary : salarys) {
			salaryroll.setYyyy(yyyy);
			salaryroll.setMm(mm);
			salaryroll.setEmpno(salary.getEmpno());
			salaryroll.setDepart(salary.getDepart());
			salaryroll.setName(salary.getName());
			salaryroll.setPartner(salary.getPartner());
			salaryroll.setDependent20(salary.getDependent20()*1500000);
			salaryroll.setDependent60(salary.getDependent60()*1500000);
			salaryroll.setDisabled(salary.getDisabled()*1500000);
			salaryroll.setWomanpower(salary.getWomanpower()*1500000);
			salaryroll.setPay12(salary.getPay()*12);
			int family =1+salary.getPartner()+salary.getDependent20()+salary.getDependent60()
						+salary.getDisabled();
			int pay12 = (salary.getPay()+salary.getExtra()) * 12;
			int incomededuction = 0;
			if(family == 1) {
				if(pay12 < 30000001) {
					incomededuction = (int)(3100000 + (pay12 * 0.04));
				}else if(pay12 > 30000000 && pay12 < 45000001) {
					incomededuction = (int)(3100000 + (pay12 * 0.04) -((pay12-30000000)*0.05));
				}else if(pay12 > 45000000 && pay12 < 70000001) {
					incomededuction = (int)(3100000 + (pay12 * 0.015));
				}else if(pay12 > 70000000 && pay12 < 120000001) {
					incomededuction = (int)(3100000 + (pay12 * 0.005));
				}
			}else if(family == 2) {
				if(pay12 < 30000001) {
					incomededuction = (int)(3600000 + (pay12 * 0.04));
				}else if(pay12 > 30000000 && pay12 < 45000001) {
					incomededuction = (int)(3600000 + (pay12 * 0.04) -((pay12-30000000)*0.05));
				}else if(pay12 > 45000000 && pay12 < 70000001) {
					incomededuction = (int)(3600000 + (pay12 * 0.02));
				}else if(pay12 > 70000000 && pay12 < 120000001) {
					incomededuction = (int)(3600000 + (pay12 * 0.01));
				}
			}else {
				if(pay12 < 30000001) {
					incomededuction = (int)(5000000 + (pay12 * 0.07));
					if(((pay12-40000000)*0.04) > 0) {
						incomededuction += ((pay12-40000000)*0.04);
					}
				}else if(pay12 > 30000000 && pay12 < 45000001) {
					incomededuction = (int)(5000000 + (pay12 * 0.07) -((pay12-30000000)*0.05));
					if(((pay12-40000000)*0.04) > 0){
						incomededuction += ((pay12-40000000)*0.04);
					}
				}else if(pay12 > 45000000 && pay12 < 70000001) {
					incomededuction = (int)(5000000 + (pay12 * 0.05)+((pay12-40000000)*0.04));
				}else if(pay12 > 70000000 && pay12 < 120000001) {
					incomededuction = (int)(5000000 + (pay12 * 0.03)+((pay12-40000000)*0.04));
				}
			}
			salaryroll.setIncomededuction(incomededuction);
			int incomeamount = pay12-incomededuction;
			salaryroll.setIncomeamount(incomeamount);
			int personaldeduction = family * 1500000;	
			salaryroll.setPersonaldeduction(personaldeduction);
			int annuityinsurance = (int)(pay12 /12 * 0.045) * 12;
			salaryroll.setAnnuityinsurance(annuityinsurance);
			int standardamount = pay12 -(incomededuction + annuityinsurance +personaldeduction);
			salaryroll.setStandardamount(standardamount);
			int calculatedtax = 0;
			if(standardamount < 12000001) {
				calculatedtax = (int) (standardamount * 0.06);
			}
			else if (standardamount > 12000000 && standardamount <46000001) {
				calculatedtax = (int) (720000 + (standardamount-12000000) * 0.15);
			}
			else if (standardamount > 46000000 && standardamount <88000001) {
				calculatedtax = (int) (5820000 + (standardamount-46000000) * 0.24);
			}
			else if (standardamount > 88000000 && standardamount <150000001) {
				calculatedtax = (int) (15900000 + (standardamount-88000000) * 0.35);
			}
			else if (standardamount > 150000000 && standardamount <300000001) {
				calculatedtax = (int) (37600000 + (standardamount-150000000) * 0.38);
			}
			else if (standardamount > 300000000 && standardamount <500000001) {
				calculatedtax = (int) (94600000 + (standardamount-300000000) * 0.4);
			}
			else if (standardamount > 500000000){
				calculatedtax = (int) (174600000 + (standardamount-500000000) * 0.42);
			}
			salaryroll.setCalculatedtax(calculatedtax);
			int incometaxdeduction = 0;
			if(calculatedtax < 1300001) {
				incometaxdeduction = (int) (calculatedtax * 0.55);
			}else {
				incometaxdeduction = (int) (715000 + (calculatedtax-1300000)*0.30);
			}
			

			
			int decidedtax = calculatedtax - incometaxdeduction;
			salaryroll.setDecidedtax(decidedtax);
			int simpletax = (int) ((decidedtax / 12) * 0.01);
			simpletax = simpletax * 100;
			salaryroll.setSimpletax(simpletax);
			int finalpay = (salary.getPay()+salary.getExtra()) - (annuityinsurance+simpletax);
			salaryroll.setFinalpay(finalpay);
			
			dao.insertSalaryRoll(salaryroll);
			
		}
		
		return "redirect:index";
	}
	
	@RequestMapping(value = "/salaryTaxDelete", method = RequestMethod.POST)
	public String salaryTaxDelete(@RequestParam String yyyy, String mm) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		HashMap yyyymm = new HashMap();
		yyyymm.putIfAbsent("yyyy", yyyy);
		yyyymm.putIfAbsent("mm", mm);
		
		dao.salaryRollDeletebefore(yyyymm);
		return "redirect:index";
	}
	
	@RequestMapping(value = "/salaryRoll", method = RequestMethod.GET)
	public String salaryRoll(Locale locale, Model model) {
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
		SimpleDateFormat df_y = new SimpleDateFormat("yyyy");
		
		int today_year =  Integer.parseInt(df_y.format(date));
		int start = today_year-2;
				
		int years[] = new int[5];
		
		for(int i= 0;i < years.length; i++) {
			years[i] = start++;
		}
		
		model.addAttribute("today_year",today_year);
		model.addAttribute("years",years);
		
		String today_month = String.format("%02d", cal.get(Calendar.MONTH) +1);
		
		
		String months[] = new String[] {"01","02","03","04","05","06","07","08","09","10","11","12"};
		model.addAttribute("today_month",today_month);
		model.addAttribute("months",months);
		
		return "salary/salary_Roll";
	}
	
	@RequestMapping(value = "/salaryRollList", method = RequestMethod.POST)
	public String salaryRollList(Model model,@RequestParam String yyyy, String mm) {
		SalaryDao dao = sqlSession.getMapper(SalaryDao.class);
		
		HashMap yyyymm = new HashMap();
		yyyymm.putIfAbsent("yyyy", yyyy);
		yyyymm.putIfAbsent("mm", mm);
		ArrayList<SalaryRollViewToBean> salaryrolls = dao.selectsalaryRollView(yyyymm);
		

		model.addAttribute("salaryrolls",salaryrolls);
		
		return "salary/salaryroll_list";
	}
	

}